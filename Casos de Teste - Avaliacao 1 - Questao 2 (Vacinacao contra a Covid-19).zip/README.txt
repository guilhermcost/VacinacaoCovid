Arquivo zip gerado em: 18/04/2021 07:14:40 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Avaliação 1 - Questão 2 (Vacinação contra a Covid-19)